This folder contains some Arduino libraries and some code samples. 

For questions - check Arduino.cc/forum


